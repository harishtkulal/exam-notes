WEB TECHNOLOGIES - EXPERIMENT 2 AND 3

EXP 2
Question/Aim:
Design the following static web pages required for an online book store web site:
i. Registration Page
ii. Cart Page

Files:
- EXP-02/Registraion.html
- EXP-02/Cart.html

NOTE: The supplied manual/copy labels these files inconsistently: Registraion.html displays
the CART PAGE and Cart.html displays the CATALOGUE PAGE. This package preserves those
manual filenames/content labels while correcting HTML syntax needed for execution.

EXP 3
Question/Aim:
Design a web page using CSS which includes:
i. Use different font and text styles
ii. Set a background image for both the page and single element on the page
iii. Define styles for links
iv. Working with layers
v. Adding a Customized cursor

Files:
- EXP-03/Fontstyle.html
- EXP-03/font.css
- EXP-03/background.html
- EXP-03/background-image.html
- EXP-03/Link.html
- EXP-03/layers.html
- EXP-03/cursor.html

IMAGE NOTE:
The manual references c#.jpg, cn.jpg, wt.jpg and wt1.jpg, but those image files were not
provided as separate source assets in the supplied copy. Add them to the relevant folders
if available. The pages still open without them; the images simply will not display.

RUN:
Open each .html file in a web browser. Fontstyle.html requires font.css in the same folder.


IMAGES INCLUDED IN THIS PACKAGE:
The original source/copy referenced image filenames but did not provide the actual image files.
To make the HTML/CSS examples executable, this package includes simple DEMO PLACEHOLDER images
with the required filenames: c#.jpg, cn.jpg, wt.jpg and wt1.jpg.
They are not the original images from the KSOU manual.
